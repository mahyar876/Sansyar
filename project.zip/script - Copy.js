// =========================
// SCROLL ANIMATION
// =========================

const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("show");
        }
      });
    },
    {
      threshold: 0.2,
    }
  );
  
  document
    .querySelectorAll(".card, .how-step, .stat")
    .forEach((el) => observer.observe(el));
  
  
  // =========================
  // COUNTER ANIMATION
  // =========================
  
  const counters = document.querySelectorAll("[data-target]");
  
  counters.forEach((counter) => {
    const updateCounter = () => {
      const target = +counter.dataset.target;
      const current = +counter.innerText;
  
      const increment = target / 100;
  
      if (current < target) {
        counter.innerText = Math.ceil(current + increment);
        requestAnimationFrame(updateCounter);
      } else {
        counter.innerText = target.toLocaleString("fa-IR");
      }
    };
  
    updateCounter();
  });
  
  
  // =========================
  // BACK TO TOP BUTTON
  // =========================
  
  const topBtn = document.getElementById("topBtn");
  
  window.addEventListener("scroll", () => {
    if (window.scrollY > 500) {
      topBtn.classList.add("active");
    } else {
      topBtn.classList.remove("active");
    }
  });
  
  topBtn.addEventListener("click", () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  });

  /* ══════════════════════════════════════
   DATA
══════════════════════════════════════ */
const pitches = [
  { id:1, name:'سالن فوتسال آریا',     type:'futsal', size:5,  cover:'#0d3320', price:180000, avail:6, tags:['سرپوشیده','رختکن','کفپوش'] },
  { id:2, name:'چمن فوتبال پارک ملت',  type:'grass',  size:11, cover:'#0a2e10', price:320000, avail:3, tags:['چمن مصنوعی','روشنایی','پارکینگ'] },
  { id:3, name:'فوتسال ستاره شرق',     type:'futsal', size:7,  cover:'#0d2e1a', price:210000, avail:8, tags:['سرپوشیده','دوش','نوشیدنی'] },
  { id:4, name:'زمین چمن رضایی',       type:'grass',  size:7,  cover:'#082510', price:250000, avail:4, tags:['چمن طبیعی','تریبون','بوفه'] },
  { id:5, name:'سالن ورزشی امید',      type:'futsal', size:5,  cover:'#0d3320', price:160000, avail:5, tags:['سرپوشیده','رختکن'] },
  { id:6, name:'چمن فوتبال دانشگاه',  type:'grass',  size:11, cover:'#0a2e10', price:280000, avail:2, tags:['چمن مصنوعی','روشنایی'] },
];

const typeLabel = { futsal: 'فوتسال', grass: 'چمن' };

// Slots per pitch — هر زمین سانس‌های متفاوتی داره
const slotsData = {
  1: [false,true,false,false,true,false,false,true,false,false,true,false],
  2: [true,false,false,true,false,true,false,false,true,false,false,true],
  3: [false,false,true,false,false,false,true,false,true,false,false,false],
  4: [true,true,false,false,true,false,false,false,false,true,false,false],
  5: [false,true,false,true,false,false,true,false,false,true,false,false],
  6: [true,false,true,false,true,false,false,true,false,false,true,false],
};

const slotTimes = [
  '۰۸:۰۰–۰۹:۰۰','۰۹:۰۰–۱۰:۰۰','۱۰:۰۰–۱۱:۰۰','۱۱:۰۰–۱۲:۰۰',
  '۱۴:۰۰–۱۵:۰۰','۱۵:۰۰–۱۶:۰۰','۱۶:۰۰–۱۷:۰۰','۱۷:۰۰–۱۸:۰۰',
  '۱۸:۰۰–۱۹:۰۰','۱۹:۰۰–۲۰:۰۰','۲۰:۰۰–۲۱:۰۰','۲۱:۰۰–۲۲:۰۰',
];

/* ══════════════════════════════════════
   STATE
══════════════════════════════════════ */
let selectedPitch   = null;
let selectedSlot    = null;  // index into slotTimes
let filteredList    = [...pitches];

/* ══════════════════════════════════════
   HELPERS
══════════════════════════════════════ */
function numFa(n) {
  return n.toString().replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
}

function priceFa(n) {
  return numFa(n.toLocaleString('en'));
}

/* ══════════════════════════════════════
   RENDER PITCHES
══════════════════════════════════════ */
function renderPitches() {
  const grid = document.getElementById('pitchesGrid');
  const countEl = document.getElementById('pitchCount');

  countEl.textContent = numFa(filteredList.length) + ' زمین در دسترس';

  if (filteredList.length === 0) {
    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-muted)">هیچ زمینی با این فیلتر پیدا نشد</div>';
    return;
  }

  grid.innerHTML = filteredList.map(p => `
    <div class="pitch-card ${selectedPitch && selectedPitch.id === p.id ? 'selected' : ''}"
         onclick="selectPitch(${p.id})">
      <div class="select-check">✓</div>
      <div class="pitch-thumb" style="background:linear-gradient(140deg,${p.cover},#060e09)">
        <div class="pitch-thumb-circle"></div>
        <div class="pitch-type-badge">${typeLabel[p.type]}</div>
      </div>
      <div class="pitch-body">
        <div class="pitch-name">${p.name}</div>
        <div class="pitch-meta">
          ${p.tags.map(t => `<span class="pitch-tag">${t}</span>`).join('')}
          <span class="pitch-tag">${numFa(p.size)} نفره</span>
        </div>
        <div class="pitch-price-row">
          <div class="pitch-price">${priceFa(p.price)} <span>تومان/ساعت</span></div>
          <div class="pitch-avail"><strong>${numFa(p.avail)}</strong> سانس خالی</div>
        </div>
      </div>
    </div>
  `).join('');
}

/* ══════════════════════════════════════
   SELECT PITCH
══════════════════════════════════════ */
function selectPitch(id) {
  selectedPitch = pitches.find(p => p.id === id);
  selectedSlot  = null;

  renderPitches();
  renderSlots();
  updateSummary();
  setStep(2);

  setTimeout(() => {
    document.getElementById('slotsSection').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, 80);
}

/* ══════════════════════════════════════
   RENDER SLOTS
══════════════════════════════════════ */
function renderSlots() {
  const sec  = document.getElementById('slotsSection');
  const grid = document.getElementById('slotsGrid');
  const nameEl = document.getElementById('selectedPitchName');

  if (!selectedPitch) {
    sec.style.display = 'none';
    return;
  }

  nameEl.textContent = selectedPitch.name;
  sec.style.display  = 'block';

  const taken = slotsData[selectedPitch.id];

  grid.innerHTML = slotTimes.map((time, i) => {
    const isTaken    = taken[i];
    const isSelected = selectedSlot === i;
    const priceK     = Math.round(selectedPitch.price / 1000);
    return `
      <div class="slot ${isTaken ? 'slot-taken' : ''} ${isSelected ? 'slot-selected' : ''}"
           onclick="${isTaken ? '' : 'selectSlot(' + i + ')'}">
        <span class="slot-time">${time}</span>
        <span class="slot-price">${isTaken ? 'رزرو شده' : numFa(priceK) + 'K'}</span>
      </div>
    `;
  }).join('');
}

/* ══════════════════════════════════════
   SELECT SLOT
══════════════════════════════════════ */
function selectSlot(i) {
  selectedSlot = i;
  renderSlots();
  updateSummary();
  setStep(3);
  checkSubmit();
}

/* ══════════════════════════════════════
   UPDATE SUMMARY SIDEBAR
══════════════════════════════════════ */
function updateSummary() {
  const el = document.getElementById('summaryContent');

  if (!selectedPitch) {
    el.innerHTML = '<div class="summary-empty">هنوز زمینی انتخاب نشده</div>';
    return;
  }

  const dateVal = document.getElementById('dateFilter').value;
  let dateStr = 'انتخاب نشده';
  if (dateVal) {
    try { dateStr = new Date(dateVal).toLocaleDateString('fa-IR'); } catch(e) { dateStr = dateVal; }
  }

  const slotStr = selectedSlot !== null ? slotTimes[selectedSlot] : 'انتخاب نشده';

  el.innerHTML = `
    <div class="summary-row"><span class="label">زمین</span><span class="value">${selectedPitch.name}</span></div>
    <div class="summary-row"><span class="label">نوع</span><span class="value">${typeLabel[selectedPitch.type]}</span></div>
    <div class="summary-row"><span class="label">تاریخ</span><span class="value">${dateStr}</span></div>
    <div class="summary-row"><span class="label">ساعت</span><span class="value">${slotStr}</span></div>
    <div class="summary-row"><span class="label">مبلغ</span><span class="value green">${priceFa(selectedPitch.price)} تومان</span></div>
  `;

  checkSubmit();
}

/* ══════════════════════════════════════
   FILTER
══════════════════════════════════════ */
function applyFilter() {
  const type = document.getElementById('typeFilter').value;   // '' | 'futsal' | 'grass'
  const size = parseInt(document.getElementById('sizeFilter').value) || 0; // 0=all
  const sort = document.getElementById('sortFilter').value;

  filteredList = pitches.filter(p => {
    const typeOk = !type || p.type === type;
    const sizeOk = !size || p.size === size;
    return typeOk && sizeOk;
  });

  if (sort === 'price') filteredList.sort((a, b) => a.price - b.price);
  if (sort === 'avail') filteredList.sort((a, b) => b.avail - a.avail);

  // اگه زمین انتخاب‌شده از فیلتر حذف شد، ریست کن
  if (selectedPitch && !filteredList.find(p => p.id === selectedPitch.id)) {
    selectedPitch = null;
    selectedSlot  = null;
    renderSlots();
    updateSummary();
    setStep(1);
  }

  renderPitches();
}

/* ══════════════════════════════════════
   CHECK SUBMIT
══════════════════════════════════════ */
function checkSubmit() {
  const name  = document.getElementById('userName').value.trim();
  const phone = document.getElementById('userPhone').value.trim();
  const phoneOk = /^09[0-9]{9}$/.test(phone.replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
  const ok = selectedPitch && selectedSlot !== null && name.length >= 3 && phoneOk;

  const btn = document.getElementById('submitBtn');
  btn.disabled = !ok;

  // نشون بده چی کمه
  const phoneEl = document.getElementById('userPhone');
  if (phone && !phoneOk) {
    phoneEl.style.borderColor = '#ef4444';
  } else {
    phoneEl.style.borderColor = '';
  }

  if (ok) setStep(4);
  else if (selectedPitch && selectedSlot !== null) setStep(3);
}

/* ══════════════════════════════════════
   STEPS BAR
══════════════════════════════════════ */
function setStep(n) {
  const labels = ['','۱','۲','۳','۴'];
  for (let i = 1; i <= 4; i++) {
    const item   = document.getElementById('step' + i + '-item');
    const circle = item.querySelector('.step-circle');
    if (i < n) {
      item.className     = 'step-item done';
      circle.textContent = '✓';
    } else if (i === n) {
      item.className     = 'step-item active';
      circle.textContent = labels[i];
    } else {
      item.className     = 'step-item';
      circle.textContent = labels[i];
    }
  }
}

/* ══════════════════════════════════════
   OPEN PAY MODAL
══════════════════════════════════════ */
function openPayModal() {
  if (!selectedPitch || selectedSlot === null) return;

  const name    = document.getElementById('userName').value.trim();
  const phone   = document.getElementById('userPhone').value.trim();
  const count   = document.getElementById('userCount').value;
  const note    = document.getElementById('userNote').value.trim();
  const dateVal = document.getElementById('dateFilter').value;
  let dateStr = '—';
  if (dateVal) {
    try { dateStr = new Date(dateVal).toLocaleDateString('fa-IR'); } catch(e) { dateStr = dateVal; }
  }
  const slotStr = slotTimes[selectedSlot];

  document.getElementById('modalSummary').innerHTML = `
    <div class="modal-row"><span class="ml">زمین</span><span class="mr">${selectedPitch.name}</span></div>
    <div class="modal-row"><span class="ml">نوع</span><span class="mr">${typeLabel[selectedPitch.type]}</span></div>
    <div class="modal-row"><span class="ml">تاریخ</span><span class="mr">${dateStr}</span></div>
    <div class="modal-row"><span class="ml">ساعت</span><span class="mr">${slotStr}</span></div>
    <div class="modal-row"><span class="ml">رزروکننده</span><span class="mr">${name}</span></div>
    <div class="modal-row"><span class="ml">موبایل</span><span class="mr">${phone}</span></div>
    <div class="modal-row"><span class="ml">نفرات</span><span class="mr">${count}</span></div>
    ${note ? `<div class="modal-row"><span class="ml">توضیحات</span><span class="mr">${note}</span></div>` : ''}
    <div class="modal-row total">
      <span class="ml">مبلغ کل</span>
      <span class="mr">${priceFa(selectedPitch.price)} تومان</span>
    </div>
  `;

  document.getElementById('payModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

/* ══════════════════════════════════════
   CLOSE PAY MODAL
══════════════════════════════════════ */
function closePayModal() {
  document.getElementById('payModal').classList.remove('open');
  document.body.style.overflow = '';
}

/* ══════════════════════════════════════
   DO PAYMENT
══════════════════════════════════════ */
function doPayment() {
  // mark selected slot as taken
  slotsData[selectedPitch.id][selectedSlot] = true;
  // reduce avail count
  const p = pitches.find(x => x.id === selectedPitch.id);
  if (p && p.avail > 0) p.avail--;

  closePayModal();

  const code = 'SNS-' + Math.random().toString(36).substr(2, 6).toUpperCase();
  document.getElementById('reserveCode').textContent = code;
  document.getElementById('successModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

/* ══════════════════════════════════════
   CLOSE ON OVERLAY CLICK
══════════════════════════════════════ */
document.addEventListener('click', function(e) {
  if (e.target.id === 'payModal') closePayModal();
});

/* ══════════════════════════════════════
   INIT
══════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', function() {
  // تاریخ امروز
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('dateFilter').value = today;

  // live validation
  document.getElementById('userName').addEventListener('input', checkSubmit);
  document.getElementById('userPhone').addEventListener('input', checkSubmit);

  // render
  renderPitches();
});
