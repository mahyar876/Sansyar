const express    = require('express');
const mongoose   = require('mongoose');
const cors       = require('cors');
const dotenv     = require('dotenv');
const rateLimit  = require('express-rate-limit');

dotenv.config();

const app = express();

// ── MIDDLEWARE ──
app.use(express.json());
app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  credentials: true,
}));

// Rate limiting — جلوگیری از abuse
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 دقیقه
  max: 100,
  message: { success: false, message: 'درخواست‌های زیادی ارسال کردی. کمی صبر کن.' }
});
app.use('/api/', limiter);

// Rate limit سخت‌تر برای auth
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { success: false, message: 'تلاش‌های زیاد. ۱۵ دقیقه دیگر امتحان کن.' }
});
app.use('/api/auth/', authLimiter);

// ── ROUTES ──
app.use('/api/auth',         require('./routes/auth'));
app.use('/api/pitches',      require('./routes/pitches'));
app.use('/api/reservations', require('./routes/reservations'));

// ── HEALTH CHECK ──
app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    message: 'سانس‌یار آنلاینه 🟢',
    time: new Date().toISOString(),
    db: mongoose.connection.readyState === 1 ? 'متصل' : 'قطع'
  });
});

// ── 404 ──
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'مسیر پیدا نشد' });
});

// ── ERROR HANDLER ──
app.use((err, req, res, next) => {
  console.error('❌ خطا:', err.message);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'خطای سرور'
  });
});

// ── DB + START ──
mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('✅ MongoDB متصل شد');
    // Seed زمین‌ها اگه خالیه
    require('./models/Pitch').countDocuments().then(count => {
      if (count === 0) require('./seeds/pitches')();
    });
  })
  .catch(err => {
    console.error('❌ خطای MongoDB:', err.message);
    process.exit(1);
  });

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 سرور روی پورت ${PORT} شروع به کار کرد`);
  console.log(`📍 http://localhost:${PORT}/api/health`);
});
